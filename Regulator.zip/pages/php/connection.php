<?php

    $con= mysqli_connect("103.21.59.27", "wtintern_bob", "Tiger@1995", "wtintern_heldon")
    or die("Unable to connect to the database server!");
?>