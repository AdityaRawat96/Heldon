<footer class="footer">
    <div class="container-fluid">
        <p class="copyright pull-left">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            <a href="http://wtsolutions.cc">Heldon</a> Admin Dashboard
        </p>
    </div>
</footer>
